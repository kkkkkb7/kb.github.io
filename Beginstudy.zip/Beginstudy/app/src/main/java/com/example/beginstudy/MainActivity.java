package com.example.beginstudy;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent intenttask =new Intent(MainActivity.this,studyhistory.class);
        Intent intenthistory =new Intent(MainActivity.this,studyhistory.class);
        Intent intentstudy =new Intent(MainActivity.this,study.class);

        Button btntask = (Button) findViewById(R.id.btntask);
        Button btnhistory = (Button) findViewById(R.id.btnhistory);
        Button btnstudy = (Button) findViewById(R.id.btnstudy);

        btntask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(intenttask);
            }
        });
        btnhistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(intenthistory);
            }
        });
        btnstudy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(intentstudy);
            }
        });
    }
}