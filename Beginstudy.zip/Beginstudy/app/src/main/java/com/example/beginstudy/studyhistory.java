package com.example.beginstudy;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class studyhistory extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_studyhistory);
        Intent intentback1 =new Intent(studyhistory.this,MainActivity.class);
        Button btnback1 =(Button) findViewById(R.id.backhistory);

        btnback1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(intentback1);
            }
        });
    }
}